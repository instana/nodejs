# Changelog

## 1.4.1
 - Fix issues caused by `uv_hrtime()` returning a value that is greater than the max possible `uint32` value.

## 1.4.0
 - Expose TypeScript types.

## 1.3.0
 - Detect synchronous blocks

## 1.2.0
 - Support Node.js v12

## 1.1.0
 - Support Node.js v10

## 1.0.0
 - Initial release
