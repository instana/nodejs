# Changelog

## 1.3.0
 - Detect synchronous blocks

## 1.2.0
 - Support Node.js v12

## 1.1.0
 - Support Node.js v10

## 1.0.0
 - Initial release
