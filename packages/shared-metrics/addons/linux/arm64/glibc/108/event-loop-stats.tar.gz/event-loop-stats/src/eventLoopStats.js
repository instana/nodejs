var eventLoopStats = require('../build/Release/eventLoopStats');
exports.sense = eventLoopStats.sense;
